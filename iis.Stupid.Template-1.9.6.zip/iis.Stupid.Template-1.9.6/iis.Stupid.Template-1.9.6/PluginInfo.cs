﻿namespace StupidTemplate
{
    public class PluginInfo
    {
        public const string GUID = "liquidclientjdshfjksdgfjhgfjhdsgfjhdsgfjhs.com";
        public const string Name = " liquid.client";
        public const string Description = "liquid on top creds to dot and cdev";
        public const string Version = "1.9.6";
    }
}
